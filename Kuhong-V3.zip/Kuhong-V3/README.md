# NfQ-BoT
Simple WhatsApp Bot

### FOR TERMUX USER
```bash
> pkg update && pkg upgrade
> pkg install git
> pkg install nodejs
> pkg install ffmpeg
> pkg install imagemagick
> git clone https://github.com/Arya274/Arya-Bot
> cd Arya-Bot
> npm install
```
###### Run
```bash
> node . [<session name>] (session name is optional)
```

---------

### FOR WINDOWS/VPS/RDP USER
```bash
> git clone https://github.com/Arya274/Arya-Bot
> cd Arya-Bot
> npm install
```
###### Run
```bash
> node index.js
```
 SOSMED:
 
 Instagram: @arpunchs
 
 Youtube: Drawl Nag
